﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace LogisticsABCMVCCore.Models
{

    public class ShipmentContext:DbContext
    {
        public ShipmentContext(DbContextOptions<ShipmentContext>options):base(options)
        {

        }
        public DbSet<Shipment> Shipments { get; set; }
    }
}
