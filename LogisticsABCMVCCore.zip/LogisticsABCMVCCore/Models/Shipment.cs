﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace LogisticsABCMVCCore.Models
{
    public class Shipment
    {
        [Key]
        public int ShipmentId { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public string SenderName { get; set; }
        [Column(TypeName = "varchar(10)")]
        public string Description { get; set; }
        [Column(TypeName = "varchar(100)")]
        public string RecipientAddress { get; set; }
        [Column(TypeName = "varchar(250)")]
        public string Expedited { get; set; }

        [Column(TypeName = "varchar(250)")]
        public string ShipmentType { get; set; }


    }
    
}
